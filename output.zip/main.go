package main

import "github.com/IsmailCLN/tapir/cmd"

func main() {
	cmd.Execute()
}
