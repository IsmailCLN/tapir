package assert

const (
	keyInjectedHeaders = "headers"
	keyHeaderName      = "header"
	keyExpectedValue   = "value"
	keyStatus          = "status_code"
	keyMin             = "min"
	keyMax             = "max"
)
